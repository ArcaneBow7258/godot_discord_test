# Attribution
## Collaborators

### Art
[Cup Nooble](https://cupnooble.itch.io/)

### Code and Documentation
[Maaack](https://maaack.itch.io/)

## Tools
#### Godot
Author: [Juan Linietsky, Ariel Manzur, and contributors](https://godotengine.org/contact)  
Source: [godotengine.org](https://godotengine.org/)  
License: [MIT License](https://github.com/godotengine/godot/blob/master/LICENSE.txt) 

#### Visual Studio Code
Author: [Microsoft](https://opensource.microsoft.com/)  
Source: [github: vscode](https://github.com/microsoft/vscode)  
License: [MIT License](https://github.com/microsoft/vscode/blob/main/LICENSE.txt)

#### Git
Author: [Linus Torvalds](https://github.com/torvalds)  
Source: [git-scm.com](https://git-scm.com/downloads)  
License: [GNU General Public License version 2](https://opensource.org/licenses/GPL-2.0)
